let navbar = document.querySelector('.navbar');

document.querySelector('#bars-btn').onclick = () =>{
    navbar.classList.toggle('active');
}